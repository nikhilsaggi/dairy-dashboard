# dairy-dashboard
a scalable interface for displaying cow and herd performance from live data streams
